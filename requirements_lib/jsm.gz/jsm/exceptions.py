# coding=utf-8


class CCODENotFoundException(Exception):
    pass
